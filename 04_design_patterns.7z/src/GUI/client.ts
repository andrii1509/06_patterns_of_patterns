import {MockGui} from "./mock-gui";
import {Shipment} from "../shipment/shipment";

export class Client {

  constructor(gui: MockGui) {}

  private onShip(shipment: Shipment) {}
}