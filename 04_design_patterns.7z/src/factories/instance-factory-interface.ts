export interface InstanceFactoryInterface {
  getInstance(field: string | number): any;
}
