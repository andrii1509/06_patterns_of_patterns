import {AssetInterface} from './asset-interface';

export class Oversize implements AssetInterface {
  constructor() {}
}