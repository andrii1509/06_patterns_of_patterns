import {AssetInterface} from './asset-interface';

export class Letter implements AssetInterface {
  constructor() {}
}