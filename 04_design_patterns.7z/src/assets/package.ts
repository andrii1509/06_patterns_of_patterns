import {AssetInterface} from './asset-interface';

export class Package implements AssetInterface {
  constructor() {}
}